import React from 'react';
import Table from './Components/Table'
import './App.css';

function App() {
  return (
    <div className="App">
    <Table/>
    </div>
  );
}

export default App;
