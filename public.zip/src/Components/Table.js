import React  from 'react';
import './Table.css';

function table(){
    return(
        <>
 
    <header>
        <h2>time table</h2>
    </header>
    <div className="tableh">
        <div className="table">
            <div className="column">
                <div className="row" >Day/Period</div>
                <div className="row" >Monday</div>
                <div className="row" >Tuesday</div>
                <div className="row" >Wednesday</div>
                <div className="row" >Thursday</div>
                <div className="row" >Friday</div>
                <div className="row" >Saturday</div>
            </div>
            <div className="column">
                <div className="row" >I<br />
                    9:30-10:20</div>
                <div className="row">Eng</div>
                <div className="rowc">LAB</div>
                <div className="row">Mat </div>
                <div className="row">Phy </div>
                <div className="rowc">LAB </div>
                <div className="row">Eng </div>
            </div>
            <div className="column">
                <div className="row" >II<br />
                    10:20-11:10</div>
                <div className="row">Mat</div>
                <div className="rowd"></div>
                <div className="row">Phy</div>
                <div className="row">Eng </div>
                <div className="rowud"></div>
                <div className="row">Che </div>
            </div>
            <div className="column">
                <div className="row" >III<br />
                    11:10-12:00</div>
                <div className="row">Che </div>
                <div className="rowd"></div>
                <div className="row">Eng</div>
                <div className="row">Che </div>
                <div className="rowud"></div>
                <div className="row">Mat </div>
            </div>
            <div className="column">
                <div className="row" >12:00-12:40</div>
                <div className="rowh">
                    <br />L<br />
                    <br />
                    <br />
                    U<br />
                    <br />
                    <br />

                    N<br />
                    <br />
                    <br />
                    C<br />
                    <br />
                    <br />
                    H
                </div>

            </div>
            <div className="column">
                <div className="row" >IV<br />
                    12:40-1:30</div>
                <div className="rowc">LAB</div>
                <div className="row">Eng </div>
                <div className="row">Che</div>
                <div className="rowc">LAB</div>
                <div className="row">Mat </div>
                <div className="rowc">SEMINAR </div>
            </div>
            <div className="column">
                <div className="row" >V<br />
                    1:30-2:20</div>
                <div className="rowd"></div>
                <div className="row">Che</div>
                <div className="rowc">LIBRARY</div>
                <div className="rowud"></div>
                <div className="row">Che </div>
                <div className="rowd"></div>
            </div>
            <div className="column">
                <div className="row" >VI<br />
                    2:20-3:10</div>
                <div className="rowud"></div>
                <div className="row">Mat</div>
                <div className="rowud"></div>
                <div className="rowud"></div>
                <div className="row">Eng </div>
                <div className="rowd"></div>
            </div>
            <div className="column">
                <div className="row" >VII<br />
                    3:10-4:00</div>
                <div className="row">Phy</div>
                <div className="row">SPORTS</div>
                <div className="rowud"></div>
                <div className="row">Mat</div>
                <div className="row">Phy</div>
                <div className="row">SPORTS</div>
            </div>
        </div>
    </div>

        </>

    );


}

export default table;